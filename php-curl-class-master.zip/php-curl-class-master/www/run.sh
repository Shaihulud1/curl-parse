docker run \
    --detach \
    --name www.phpcurlclass.com \
    -p 8001:80 \
    php-curl-class/php-curl-class:latest
