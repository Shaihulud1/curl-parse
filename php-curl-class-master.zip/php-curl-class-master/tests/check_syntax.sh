phpcs \
    --extensions="php" \
    --ignore="*/vendor/*" \
    --standard="ruleset.xml" \
    -p \
    -s \
    ..
